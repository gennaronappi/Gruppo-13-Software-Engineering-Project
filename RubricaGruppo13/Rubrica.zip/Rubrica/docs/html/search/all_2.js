var searchData=
[
  ['interfacciaaggiungimodifica_0',['InterfacciaAggiungiModifica',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_aggiungi_modifica.html',1,'com::mycompany::rubrica']]],
  ['interfacciaelimina_1',['InterfacciaElimina',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_elimina.html',1,'com::mycompany::rubrica']]],
  ['interfacciarubrica_2',['InterfacciaRubrica',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_rubrica.html',1,'com::mycompany::rubrica']]],
  ['interfacciaupload_3',['InterfacciaUpload',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_upload.html',1,'com::mycompany::rubrica']]]
];
