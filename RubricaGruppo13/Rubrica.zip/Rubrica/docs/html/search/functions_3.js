var searchData=
[
  ['rimuovicontatto_0',['rimuoviContatto',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_elimina.html#ad87838711a6cf5fcdc6a3ff6a279484d',1,'com::mycompany::rubrica::InterfacciaElimina']]]
];
