var searchData=
[
  ['setcognome_0',['setCognome',['../classcom_1_1mycompany_1_1rubrica_1_1_contatto.html#aa201d1588063a84277b5b38ba13df1c0',1,'com::mycompany::rubrica::Contatto']]],
  ['setnome_1',['setNome',['../classcom_1_1mycompany_1_1rubrica_1_1_contatto.html#a68f939deede031c7c0c27306ca3c7280',1,'com::mycompany::rubrica::Contatto']]],
  ['start_2',['start',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_rubrica.html#ae044ec5fb62d9491f32fe9c225a7ebd0',1,'com::mycompany::rubrica::InterfacciaRubrica']]]
];
