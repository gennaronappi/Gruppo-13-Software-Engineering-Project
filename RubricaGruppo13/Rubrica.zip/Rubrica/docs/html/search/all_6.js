var searchData=
[
  ['tostring_0',['toString',['../classcom_1_1mycompany_1_1rubrica_1_1_contatto.html#a9132a12abaa2a0bc1a1a1bcc35bf0353',1,'com::mycompany::rubrica::Contatto']]],
  ['trascinafiletoupload_1',['trascinaFileToUpload',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_upload.html#a6574755b2725429e2b812b92f7d2dd5c',1,'com::mycompany::rubrica::InterfacciaUpload']]]
];
