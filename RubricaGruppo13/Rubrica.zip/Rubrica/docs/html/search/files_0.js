var searchData=
[
  ['interfacciarubrica_2ejava_0',['InterfacciaRubrica.java',['../_interfaccia_rubrica_8java.html',1,'']]]
];
