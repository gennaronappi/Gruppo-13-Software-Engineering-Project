var searchData=
[
  ['contatto_0',['Contatto',['../classcom_1_1mycompany_1_1rubrica_1_1_contatto.html#aeb42cf52f8a0f47b09ec332d67df6fa5',1,'com::mycompany::rubrica::Contatto']]]
];
