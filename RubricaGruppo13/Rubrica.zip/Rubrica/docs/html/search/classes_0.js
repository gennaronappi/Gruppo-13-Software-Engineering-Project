var searchData=
[
  ['contatto_0',['Contatto',['../classcom_1_1mycompany_1_1rubrica_1_1_contatto.html',1,'com::mycompany::rubrica']]]
];
