var searchData=
[
  ['main_0',['main',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_rubrica.html#a5a771f47c0da4bbb456ee92020f14890',1,'com.mycompany.rubrica.InterfacciaRubrica.main()'],['../classcom_1_1mycompany_1_1rubrica_1_1_rubrica.html#a7b697d5b3e009c6fb995d3438331bff6',1,'com.mycompany.rubrica.Rubrica.main()']]]
];
