var searchData=
[
  ['getcognome_0',['getCognome',['../classcom_1_1mycompany_1_1rubrica_1_1_contatto.html#a30dadd9bf8db32d55c183834394f15ab',1,'com.mycompany.rubrica.Contatto.getCognome()'],['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_aggiungi_modifica.html#a4e61043b670ec3f286c5f52c99e12bbb',1,'com.mycompany.rubrica.InterfacciaAggiungiModifica.getCognome()']]],
  ['getemail_1',['getEmail',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_aggiungi_modifica.html#a1b81089b164fc5e4eec687bb391dfbd1',1,'com::mycompany::rubrica::InterfacciaAggiungiModifica']]],
  ['getnome_2',['getNome',['../classcom_1_1mycompany_1_1rubrica_1_1_contatto.html#adf412e5859fbbd25c562725fe1b72657',1,'com.mycompany.rubrica.Contatto.getNome()'],['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_aggiungi_modifica.html#a0321ca91373fee6be65058c5567edd73',1,'com.mycompany.rubrica.InterfacciaAggiungiModifica.getNome()']]],
  ['getnumerotelefono_3',['getNumeroTelefono',['../classcom_1_1mycompany_1_1rubrica_1_1_interfaccia_aggiungi_modifica.html#aea734b063865533595d1a586a236a402',1,'com::mycompany::rubrica::InterfacciaAggiungiModifica']]]
];
