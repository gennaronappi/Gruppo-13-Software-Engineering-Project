var indexSectionsWithContent =
{
  0: "cgimrst",
  1: "cir",
  2: "cgmrst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

